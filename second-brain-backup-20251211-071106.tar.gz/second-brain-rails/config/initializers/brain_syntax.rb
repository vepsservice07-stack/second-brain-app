Rails.application.config.to_prepare do
  require_relative '../../lib/syntax/brain_parser'
end
