Rails.application.routes.draw do
  devise_for :users
  
  resources :notes do
    member do
      post :receive_rhythm
    end
  end
  
  resource :profile, only: [:show]
  
  get 'veps/status', to: 'veps#status'
  
  root "notes#index"
  
  get "up" => "rails/health#show", as: :rails_health_check
end
